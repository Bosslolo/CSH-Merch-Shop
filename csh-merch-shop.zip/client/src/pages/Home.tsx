/**
 * CSH Merch Shop — Home Page
 * Design: Gemeinschaft (Community) — Contemporary Editorial Fashion
 * Color: CSH Navy #0F1F3D + Warm Off-White + Gold accent
 * Typography: Playfair Display (display) + DM Sans (body) + DM Mono (labels)
 * Layout: Asymmetric editorial, photography-first, full-bleed sections
 */

import { useEffect, useState } from "react";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import MarqueeTicker from "@/components/MarqueeTicker";
import ManifestSection from "@/components/ManifestSection";
import NewCollectionSection from "@/components/NewCollectionSection";
import OriginalPiecesSection from "@/components/OriginalPiecesSection";
import CommunitySection from "@/components/CommunitySection";
import FooterSection from "@/components/FooterSection";

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#F5F2ED] overflow-x-hidden">
      <Navigation scrollY={scrollY} />
      <HeroSection />
      <MarqueeTicker dark={false} />
      <ManifestSection />
      <MarqueeTicker dark={true} />
      <NewCollectionSection />
      <OriginalPiecesSection />
      <CommunitySection />
      <FooterSection />
    </div>
  );
}
