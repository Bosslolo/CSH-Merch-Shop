/**
 * MarqueeTicker — CSH Merch Shop
 * Scrolling ticker strip with brand messages
 * Used between sections for editorial rhythm
 */

interface MarqueeTickerProps {
  dark?: boolean;
}

const TICKER_ITEMS = [
  "Christliche Schule im Hegau",
  "Seit 2006",
  "Lerne lernen — lerne leben",
  "Hilzingen · Baden-Württemberg",
  "Gemeinschaft",
  "CSH Merch",
  "Miteinander · Voneinander · Füreinander",
];

export default function MarqueeTicker({ dark = false }: MarqueeTickerProps) {
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS]; // duplicate for seamless loop

  return (
    <div
      className="overflow-hidden py-3 border-y"
      style={{
        backgroundColor: dark ? "#0F1F3D" : "#F5F2ED",
        borderColor: dark ? "rgba(245,242,237,0.1)" : "rgba(15,31,61,0.1)",
      }}
    >
      <div
        className="flex gap-0 whitespace-nowrap"
        style={{
          animation: "marquee 30s linear infinite",
          width: "max-content",
        }}
      >
        {items.map((item, i) => (
          <span key={i} className="inline-flex items-center gap-6">
            <span
              className="font-mono-label text-[10px]"
              style={{ color: dark ? "rgba(245,242,237,0.5)" : "rgba(15,31,61,0.4)" }}
            >
              {item}
            </span>
            <span
              className="w-1 h-1 rounded-full flex-shrink-0"
              style={{ backgroundColor: dark ? "rgba(201,168,76,0.5)" : "rgba(201,168,76,0.7)" }}
            />
          </span>
        ))}
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
